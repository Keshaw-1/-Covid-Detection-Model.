# -*- coding: utf-8 -*-
"""
Created on Sat Aug 13 01:43:51 2022

@author: Keshaw Shahi
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import glob   # it is used to read large dataset
import cv2

covid = [cv2.imread(file) for file in glob.glob("C:\\Users\Keshaw Shahi\Desktop\ml\Covid/*.jpeg")]


normal = [cv2.imread(file) for file in glob.glob(r"C:\\Users\Keshaw Shahi\Desktop\ml\Normal/*.jpeg")]

# visualization

cv2.imshow("first",covid[0])
cv2.waitKey()
cv2.destroyAllWindows()

cv2.imshow("first",normal[0])
cv2.waitKey()
cv2.destroyAllWindows()


# data preprocessing

# resize all the images in a common format
# dimension--> (300,300,3)

covid_data = [cv2.resize(image,(300,300)) for image in covid]

normal_data = [cv2.resize(image,(300,300)) for image in normal]


cv2.imshow("first",covid_data[0])
cv2.waitKey()
cv2.destroyAllWindows()

cv2.imshow("first",normal_data[0])
cv2.waitKey()
cv2.destroyAllWindows()

# let us store both the covid x-rays and the normal x-rays in a single
# master dataset


covid_data = np.array(covid_data)
normal_data = np.array(normal_data)

x = np.concatenate([covid_data,normal_data])

# label generation

# we need to create certain labels to mark
# covid and normal images and the AI algorithm
# will use these labels to learn 
# difference between a covid image and normal image

# covid image---> 1
# normal---> 0

covid_label = np.ones(46)

normal_label = np.zeros(70)


y = np.concatenate([covid_label,normal_label])

# shufling the dataset and spliting it into training set
# and the test set


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test = train_test_split(x,y)



y_train_name = ["covid +ve" if i==1.0 else "normal" for i in y_train]


for i in range(20):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(x_train[i],"gray")

plt.show()


for i in range(20):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(x_train[i],"gray")
    plt.xlabel(y_train[i])

plt.show()


for i in range(20):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(x_train[i],"gray")
    plt.xlabel("label:{}".format(y_train[i]))

plt.show()


# reshape and change the data to 2D so that ml algorithm can work with it

x_train = x_train.reshape((87,270000))
x_test = x_test.reshape((29,270000))

# random forest algorithm

from sklearn.ensemble import RandomForestClassifier
rf = RandomForestClassifier(max_depth=10)
rf.fit(x_train,y_train)


y_pred = rf.predict(x_test)

rf.score(x_test,y_test)


y_pred_name = ["covid +ve" if i ==1.0 else "normal" for i in y_pred]

y_test_name = ["covid +ve" if i ==1.0 else "normal" for i in y_test]


for i in range(25):
    plt.subplot(5,5,i+1)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(x_test[i].reshape(300,300,3),"gray")
    plt.xlabel("actual:{}\nprediction:{}".format(y_test_name[i],y_pred_name[i]))

plt.tight_layout()
plt.show()
